package assistant.genuinecoder.s_assistant.main;

import android.app.Activity;

public class MainActivity extends Activity {
}
